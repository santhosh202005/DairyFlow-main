export interface Customer {
  id: number;
  name: string;
  phone: string;
  address: string;
  username?: string;
  password?: string;
  default_rate?: number;
  created_at: string;
}

export interface MilkEntry {
  id: number;
  customer_id: number;
  customer_name: string;
  date: string;
  shift: 'AM' | 'PM';
  liters: number;
  rate: number;
  amount: number;
  created_at: string;
}

export interface Advance {
  id: number;
  customer_id: number;
  customer_name: string;
  date: string;
  amount: number;
  created_at: string;
}

export interface FeedType {
  id: number;
  name: string;
  rate: number;
  created_at: string;
}

export interface FeedPurchase {
  id: number;
  customer_id: number;
  customer_name: string;
  feed_type_id: number;
  feed_name: string;
  date: string;
  quantity: number;
  amount: number;
  created_at: string;
}

export interface Stats {
  totalCustomers: number;
  todaySupply: number;
  todayAM: number;
  todayPM: number;
  monthlyRevenue: number;
  monthlyFeed?: number;
  pendingPayments: number;
}

export interface BillingRecord {
  customer_id: number;
  name: string;
  total_liters: number;
  total_amount: number;
  total_advance: number;
  total_feed: number;
  final_payable: number;
}
