import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Calendar, User, Droplets } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MilkEntry, Customer } from '../types';

interface MilkEntriesProps {
  customerId?: number;
  isAdmin?: boolean;
  defaultRate?: number;
}

export default function MilkEntries({ customerId, isAdmin = true, defaultRate }: MilkEntriesProps) {
  const [entries, setEntries] = useState<MilkEntry[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [formData, setFormData] = useState({
    customer_id: customerId ? customerId.toString() : '',
    date: new Date().toISOString().split('T')[0],
    shift: 'AM' as 'AM' | 'PM',
    liters: '',
    rate: defaultRate?.toString() || ''
  });

  useEffect(() => {
    if (formData.customer_id && isAdmin) {
      const customer = customers.find(c => c.id.toString() === formData.customer_id);
      if (customer && customer.default_rate) {
        setFormData(prev => ({ ...prev, rate: customer.default_rate?.toString() || '30' }));
      }
    }
  }, [formData.customer_id, customers, isAdmin]);

  useEffect(() => {
    fetchEntries();
    if (isAdmin) fetchCustomers();
  }, [customerId, isAdmin]);

  const fetchEntries = () => {
    const url = customerId ? `/api/entries?customerId=${customerId}` : '/api/entries';
    fetch(url)
      .then(res => res.json())
      .then(data => setEntries(data));
  };

  const fetchCustomers = () => {
    fetch('/api/customers')
      .then(res => res.json())
      .then(data => setCustomers(data));
  };

  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const response = await fetch('/api/entries', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...formData,
        customer_id: parseInt(formData.customer_id),
        liters: parseFloat(formData.liters),
        rate: formData.rate ? parseFloat(formData.rate) : undefined
      })
    });

    const data = await response.json();
    if (!response.ok) {
      setError(data.message || 'Failed to save entry');
      return;
    }

    setIsModalOpen(false);
    setFormData({ ...formData, customer_id: customerId ? customerId.toString() : '', liters: '' });
    fetchEntries();
  };

  const [showConfirmModal, setShowConfirmModal] = useState<number | null>(null);
  const [deletingId, setDeletingId] = useState<number | null>(null);

  const handleDelete = async (id: number) => {
    setDeletingId(id);
    setShowConfirmModal(null);
    try {
      const response = await fetch(`/api/entries/${id}`, { method: 'DELETE' });
      if (response.ok) {
        fetchEntries();
      } else {
        const data = await response.json();
        alert(data.message || 'Failed to delete entry');
      }
    } catch (err) {
      alert('Error connecting to server');
    } finally {
      setDeletingId(null);
    }
  };

  const currentRate = formData.rate ? parseFloat(formData.rate) : (isAdmin ? 30 : (defaultRate || 30));

  return (
    <div className="space-y-10 relative">
      <AnimatePresence>
        {showConfirmModal !== null && (
          <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-md z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white rounded-[2.5rem] shadow-2xl p-10 max-w-sm w-full text-center border border-white/20"
            >
              <div className="w-20 h-20 bg-rose-50 text-rose-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-inner">
                <Trash2 size={32} />
              </div>
              <h3 className="text-2xl font-display font-bold text-slate-900 mb-3 tracking-tight">Erase Entry?</h3>
              <p className="text-slate-400 font-medium mb-8 leading-relaxed">This will permanently remove this milk supply record from the journal.</p>
              <div className="flex gap-4">
                <button 
                  onClick={() => setShowConfirmModal(null)}
                  className="flex-1 py-4 px-4 rounded-2xl border border-slate-100 font-black text-[10px] uppercase tracking-widest text-slate-400 hover:bg-slate-50 transition-all active:scale-95"
                >
                  Go Back
                </button>
                <button 
                  onClick={() => handleDelete(showConfirmModal)}
                  className="flex-1 py-4 px-4 rounded-2xl bg-rose-500 font-black text-[10px] uppercase tracking-widest text-white hover:bg-rose-600 transition-all shadow-lg shadow-rose-100 active:scale-95"
                >
                  Delete
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-8">
        <div>
          <div className="flex items-center gap-3 mb-3">
            <span className="px-3 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-black rounded-full uppercase tracking-[0.15em]">
              Logistics
            </span>
          </div>
          <h2 className="text-5xl font-display font-bold text-slate-900 tracking-tight leading-none mb-2">
            Supply <span className="text-emerald-600">Journal</span>
          </h2>
          <p className="text-slate-500 font-medium max-w-md">
            {isAdmin ? "Track daily milk collections and manage dairy intake." : "Monitor your contributions and daily supply records."}
          </p>
        </div>

        <button
          onClick={() => {
            setFormData(prev => ({
              ...prev,
              customer_id: customerId ? customerId.toString() : '',
              date: new Date().toISOString().split('T')[0]
            }));
            setIsModalOpen(true);
          }}
          className="flex items-center gap-3 bg-slate-900 text-white px-8 py-5 rounded-[1.5rem] font-black text-xs uppercase tracking-[0.2em] hover:bg-slate-800 transition-all shadow-xl hover:shadow-slate-200 active:scale-95"
        >
          <Plus size={20} />
          New Entry
        </button>
      </div>

      <div className="bg-white rounded-[2.5rem] shadow-soft border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-50">
                <th className="px-10 py-6 font-black text-slate-300 text-[10px] uppercase tracking-[0.2em]">Timeline</th>
                <th className="px-10 py-6 font-black text-slate-300 text-[10px] uppercase tracking-[0.2em]">Batch</th>
                {isAdmin && <th className="px-10 py-6 font-black text-slate-300 text-[10px] uppercase tracking-[0.2em]">Farmer</th>}
                <th className="px-10 py-6 font-black text-slate-300 text-[10px] uppercase tracking-[0.2em]">Volume</th>
                <th className="px-10 py-6 font-black text-slate-300 text-[10px] uppercase tracking-[0.2em]">Valuation</th>
                {isAdmin && <th className="px-10 py-6 font-black text-slate-300 text-[10px] uppercase tracking-[0.2em] text-right">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {entries.map((entry) => (
                <tr key={entry.id} className="group hover:bg-emerald-50/20 transition-all">
                  <td className="px-10 py-6">
                    <p className="text-sm font-bold text-slate-900">{new Date(entry.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</p>
                    <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest leading-none mt-1">{new Date(entry.date).getFullYear()}</p>
                  </td>
                  <td className="px-10 py-6">
                    <span className={`px-2.5 py-1 rounded-md text-[10px] font-black uppercase tracking-widest ${
                      entry.shift === 'AM' ? 'bg-amber-100 text-amber-700' : 'bg-indigo-100 text-indigo-700 shadow-sm'
                    }`}>
                      {entry.shift === 'AM' ? 'Morning Shift' : 'Evening Shift'}
                    </span>
                  </td>
                  {isAdmin && (
                    <td className="px-10 py-6">
                      <div className="flex items-center gap-3">
                         <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 font-black text-[10px] uppercase">
                          {entry.customer_name?.charAt(0)}
                        </div>
                        <span className="font-bold text-slate-700 text-sm tracking-tight">{entry.customer_name}</span>
                      </div>
                    </td>
                  )}
                  <td className="px-10 py-6">
                    <p className="text-sm font-bold text-slate-900">{entry.liters.toFixed(1)} <span className="text-[10px] uppercase">Liters</span></p>
                    <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest leading-none mt-1">@ ₹{entry.rate}/L</p>
                  </td>
                  <td className="px-10 py-6 font-display font-black text-emerald-600 text-lg tracking-tight">₹{entry.amount.toFixed(0)}</td>
                  {isAdmin && (
                    <td className="px-10 py-6 text-right">
                      <button
                        disabled={deletingId === entry.id}
                        onClick={() => setShowConfirmModal(entry.id)}
                        className={`w-10 h-10 rounded-xl transition-all opacity-0 group-hover:opacity-100 flex items-center justify-center mx-auto md:ml-auto md:mr-0 ${
                          deletingId === entry.id 
                            ? 'text-slate-200 bg-slate-50' 
                            : 'text-rose-400 hover:bg-rose-50 hover:text-rose-600 shadow-sm'
                        }`}
                      >
                        <Trash2 size={18} className={deletingId === entry.id ? 'animate-pulse' : ''} />
                      </button>
                    </td>
                  )}
                </tr>
              ))}
              {entries.length === 0 && (
                <tr>
                  <td colSpan={isAdmin ? 6 : 4} className="py-32 text-center">
                    <div className="w-20 h-20 rounded-[2rem] bg-slate-50 flex items-center justify-center text-slate-200 mx-auto mb-6">
                      <Droplets size={40} />
                    </div>
                    <p className="text-lg font-display font-bold text-slate-400">Database Quiet</p>
                    <p className="text-sm text-slate-300 font-medium">No logistical entries found for this period.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-md overflow-hidden border border-white/20"
          >
            <div className="p-8 border-b border-slate-50 flex justify-between items-center">
              <div>
                <h3 className="text-2xl font-display font-bold text-slate-900 tracking-tight">Milk Entry</h3>
                <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mt-1">Supply Reconciliation</p>
              </div>
              <button 
                onClick={() => setIsModalOpen(false)} 
                className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 hover:text-rose-500 hover:bg-rose-50 transition-all"
              >
                <Plus size={24} className="rotate-45" />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-8 space-y-8">
              {error && (
                <motion.div 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-rose-50 text-rose-600 p-4 rounded-2xl text-xs font-black uppercase tracking-widest border border-rose-100 flex items-center gap-3 shadow-sm"
                >
                  <div className="w-1.5 h-1.5 bg-rose-500 rounded-full animate-pulse" />
                  {error}
                </motion.div>
              )}
              
              <div className="space-y-6">
                {isAdmin && (
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 px-1">
                      Select Farmer
                    </label>
                    <div className="relative group">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-emerald-500 transition-colors" size={18} />
                      <select
                        required
                        value={formData.customer_id}
                        onChange={(e) => setFormData({ ...formData, customer_id: e.target.value })}
                        className="w-full pl-12 pr-4 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:bg-white focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none transition-all text-sm font-bold text-slate-700 appearance-none shadow-sm"
                      >
                        <option value="">Farmer lookup...</option>
                        {customers.map(c => (
                          <option key={c.id} value={c.id}>{c.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                )}
                
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 px-1">Date</label>
                  <div className="relative group">
                    <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-emerald-500 transition-colors" size={18} />
                    <input
                      required
                      type="date"
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      className="w-full pl-12 pr-4 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:bg-white focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none transition-all text-sm font-bold text-slate-700 shadow-sm"
                    />
                  </div>
                </div>

                <div className={`grid ${isAdmin ? 'grid-cols-2' : 'grid-cols-1'} gap-6`}>
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 px-1">Volume (L)</label>
                    <div className="relative group">
                      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 font-black text-xs uppercase">L</div>
                      <input
                        required
                        type="number"
                        step="0.1"
                        placeholder="0.0"
                        value={formData.liters}
                        onChange={(e) => setFormData({ ...formData, liters: e.target.value })}
                        className="w-full pl-10 pr-4 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:bg-white focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none transition-all text-sm font-bold text-slate-700 shadow-sm"
                      />
                    </div>
                  </div>
                  {isAdmin && (
                    <div>
                      <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 px-1">Rate (₹/L)</label>
                      <div className="relative group">
                        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 font-black text-xs uppercase">₹</div>
                        <input
                          required
                          type="number"
                          step="0.1"
                          placeholder="30.0"
                          value={formData.rate}
                          onChange={(e) => setFormData({ ...formData, rate: e.target.value })}
                          className="w-full pl-10 pr-4 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:bg-white focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none transition-all text-sm font-bold text-slate-700 shadow-sm"
                        />
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 px-1">Batch Schedule</label>
                  <div className="p-1.5 bg-slate-100 rounded-2xl flex gap-1">
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, shift: 'AM' })}
                      className={`flex-1 py-3 px-4 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${
                        formData.shift === 'AM' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'
                      }`}
                    >
                      Morning
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, shift: 'PM' })}
                      className={`flex-1 py-3 px-4 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${
                        formData.shift === 'PM' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'
                      }`}
                    >
                      Evening
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-6 rounded-[1.5rem] bg-emerald-900 text-white shadow-2xl relative overflow-hidden group">
                 <div className="absolute -right-4 -top-4 w-24 h-24 bg-white/5 rounded-full blur-2xl group-hover:bg-white/10 transition-all" />
                 <div className="flex justify-between items-center relative z-10">
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-400 mb-1">Estimated Valuation</p>
                      <p className="text-4xl font-display font-bold tracking-tight">
                        ₹{formData.liters ? (parseFloat(formData.liters) * currentRate).toFixed(0) : '0'}
                      </p>
                    </div>
                    <div className="text-right">
                       <p className="text-[10px] font-black uppercase tracking-widest text-emerald-500">Active Rate</p>
                       <p className="text-sm font-bold text-emerald-400">₹{currentRate}/L</p>
                    </div>
                 </div>
              </div>

              <div className="pt-4">
                <button
                  type="submit"
                  className="w-full bg-slate-900 text-white py-5 rounded-[1.5rem] font-black uppercase tracking-[0.2em] text-xs hover:bg-slate-800 transition-all shadow-xl hover:shadow-slate-200 active:scale-95"
                >
                  Record Entry
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
}
